"""On-demand entry signal trace for a run variant (research pipeline, read-only)."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

from data_engine.contracts import TimeWindow, timeframe_ms, validate_timeframe
from data_engine.store.db import Db

from research.ema_smoke_helpers import candles_to_ohlcv_dataframe
from research.strategies.ema_pullback.execution.signal_trace import (
    SignalTraceBundleData,
    SideSignalTrace,
    build_signal_trace_from_spec,
    slice_signal_trace,
)
from research.strategies.ema_pullback.features.calculations import add_feature_columns_from_plan
from research.strategies.ema_pullback.features.plan import build_feature_plan_from_strategy_spec
from research.strategies.ema_pullback.spec_report import (
    StrategySpecReportParseError,
    strategy_spec_from_report_dict,
)

from research_api.contracts.runs import RunReport, RunVariant
from research_api.contracts.signal_trace import (
    HtfContextTrace,
    SignalTraceBundle,
    SignalTraceMeta,
    SideSignalTrace as SideSignalTraceContract,
)
from research_api.services.market_params import MarketParamError, normalize_symbol, parse_time_range_ms
from research_api.services.market_reader import MarketDataNotFoundError, _open_db
from research_api.services.results_reader import ResultsNotFoundError, load_run_report

MAX_SIGNAL_TRACE_BARS = 5000


class UnsupportedSignalTraceFamilyError(ValueError):
    """Only ema_pullback runs are supported for signal trace in MVP."""


class SignalTraceVariantNotFoundError(ValueError):
    """Variant key not present in run report."""


def _variant_from_report(report: RunReport, variant_key: str) -> RunVariant:
    for variant in report.variants:
        if variant.variant == variant_key:
            return variant
    raise SignalTraceVariantNotFoundError(f"variant not found: {variant_key!r}")


def _warmup_bars_ms(spec: Any, timeframe: str) -> int:
    base_tf = validate_timeframe(timeframe)
    base_ms = timeframe_ms(base_tf)
    lookback = int(spec.setup.lookback)
    slow_period = int(spec.anchor_stack.slow.period)
    anchor_warmup_ms = (max(lookback, slow_period) + 5) * base_ms

    context = spec.trade_management.exit_policy.context
    context_tf = base_tf if str(context.timeframe).strip() == "base" else validate_timeframe(context.timeframe)
    context_ms = timeframe_ms(context_tf)
    context_warmup_ms = (int(context.slow_period) + 5) * context_ms

    return max(anchor_warmup_ms, context_warmup_ms)


def _load_ohlcv_frame(
    *,
    symbol: str,
    timeframe: str,
    from_ms: int,
    to_ms: int,
    db_path: Path | None,
):
    sym = normalize_symbol(symbol)
    tf = validate_timeframe(timeframe.strip())
    db = _open_db(db_path)
    window = TimeWindow(from_ms, to_ms)
    candles = db.range_get(sym, tf, window)
    if len(candles) < 2:
        raise MarketParamError("not enough candles for signal trace in requested range")
    return candles_to_ohlcv_dataframe(candles)


def _to_contract(data: SignalTraceBundleData) -> SignalTraceBundle:
    def side(s: SideSignalTrace) -> SideSignalTraceContract:
        return SideSignalTraceContract(
            direction_ok=s.direction_ok,
            blockers_ok=s.blockers_ok,
            setup_ok=s.setup_ok,
            trigger_ok=s.trigger_ok,
            risk_ok=s.risk_ok,
            signal_entry=s.signal_entry,
            stop_ready=s.stop_ready,
            portfolio_entry=s.portfolio_entry,
            internals=s.internals,
        )

    return SignalTraceBundle(
        times=data.times,
        meta=SignalTraceMeta(**data.meta),
        htf_context=HtfContextTrace(**data.htf_context),
        long=side(data.long),
        short=side(data.short),
    )


@lru_cache(maxsize=16)
def _cached_full_trace_key(
    run_id: str,
    variant_key: str,
    from_ms: int,
    to_ms: int,
) -> str:
    return f"{run_id}:{variant_key}:{from_ms}:{to_ms}"


# Simple module-level cache for full-window traces before slice
_TRACE_CACHE: dict[str, SignalTraceBundle] = {}


def fetch_signal_trace_bundle(
    *,
    run_id: str,
    variant_key: str,
    from_ms: int,
    to_ms: int,
    db_path: Path | None = None,
) -> SignalTraceBundle:
    """Compute entry pipeline trace for ``[from_ms, to_ms]`` (chart view window)."""

    report = load_run_report(run_id=run_id)
    if report.family != "ema_pullback":
        raise UnsupportedSignalTraceFamilyError(
            f"signal trace supports family ema_pullback only, got {report.family!r}"
        )

    variant = _variant_from_report(report, variant_key)
    try:
        spec = strategy_spec_from_report_dict(variant.strategy_spec)
    except StrategySpecReportParseError as exc:
        raise ValueError(str(exc)) from exc

    start_ms, end_ms = parse_time_range_ms(from_ms=from_ms, to_ms=to_ms)
    from_sec = start_ms // 1000
    to_sec = end_ms // 1000

    cache_key = _cached_full_trace_key(run_id, variant_key, start_ms, end_ms)
    if cache_key in _TRACE_CACHE:
        return _TRACE_CACHE[cache_key]

    warmup_ms = _warmup_bars_ms(spec, report.timeframe)
    load_from = max(0, start_ms - warmup_ms)
    try:
        ohlcv = _load_ohlcv_frame(
            symbol=report.symbol,
            timeframe=report.timeframe,
            from_ms=load_from,
            to_ms=end_ms,
            db_path=db_path,
        )
    except MarketDataNotFoundError as exc:
        raise exc

    plan = build_feature_plan_from_strategy_spec(spec)
    enriched = add_feature_columns_from_plan(ohlcv, plan)
    full_trace = build_signal_trace_from_spec(enriched, spec, plan)
    sliced = slice_signal_trace(
        full_trace,
        from_time_sec=from_sec,
        to_time_sec=to_sec,
        max_bars=MAX_SIGNAL_TRACE_BARS,
    )
    bundle = _to_contract(sliced)
    _TRACE_CACHE[cache_key] = bundle
    if len(_TRACE_CACHE) > 32:
        _TRACE_CACHE.pop(next(iter(_TRACE_CACHE)))
    return bundle
