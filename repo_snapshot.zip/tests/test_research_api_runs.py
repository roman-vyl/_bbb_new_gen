"""Research API BFF — runs endpoints.

Requires: ``pip install -e ".[dev,workbench-api]"`` (fastapi, httpx).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

pytestmark = pytest.mark.workbench_api

from fastapi.testclient import TestClient

from research_api.main import app
from research_api.services.results_reader import (
    UnsupportedSchemaVersionError,
    list_run_summaries,
    load_run_report,
    parse_run_report,
)
from research_api.services.run_id import InvalidRunIdError, validate_run_id

_SAMPLE_REPORT = {
    "run_id": "2026-05-01T120000Z_ema_pullback_BTCUSDT_5m",
    "created_at": "2026-05-01T12:00:00Z",
    "report_schema_version": 3,
    "family": "ema_pullback",
    "symbol": "BTCUSDT",
    "timeframe": "5m",
    "candles": 10,
    "data_range": {"from_open_time_ms": 1, "to_open_time_ms": 2},
    "variants_count": 1,
    "variants": [
        {
            "variant": "v1",
            "config_id": "cfg",
            "symbol": "BTCUSDT",
            "timeframe": "5m",
            "strategy_spec": {"variant": "v1"},
            "metrics": {
                "long": {
                    "trades": 0,
                    "pnl": 0.0,
                    "return_pct": 0.0,
                    "profit_factor": None,
                    "win_rate": None,
                },
                "short": {
                    "trades": 0,
                    "pnl": 0.0,
                    "return_pct": 0.0,
                    "profit_factor": None,
                    "win_rate": None,
                },
                "total": {
                    "trades": 1,
                    "pnl": 10.0,
                    "return_pct": 0.01,
                    "profit_factor": None,
                    "win_rate": None,
                    "sharpe": 0.0,
                    "max_drawdown": 0.0,
                },
                "open_trades": {"long": 0, "short": 0, "total": 0},
            },
            "component_counters": [],
            "trade_records": [
                {
                    "trade_id": 1,
                    "direction": "long",
                    "status": "closed",
                    "entry_time_ms": 1000,
                    "exit_time_ms": 2000,
                    "entry_price": 1.0,
                    "exit_price": 1.1,
                    "size": 0.1,
                    "pnl": 1.0,
                    "return_pct": 0.01,
                    "exit_reason": "stop_loss:sl1",
                }
            ],
        }
    ],
}

_DIAGNOSTIC_BUCKET = {
    "trades": 1,
    "pnl": 9.0,
    "gross_pnl": 10.0,
    "fees_paid": 1.0,
    "profit_factor": None,
    "win_rate": 1.0,
    "avg_return_pct": 0.09,
    "avg_hold_bars": 3.0,
}

_SAMPLE_REPORT_V4 = {
    **_SAMPLE_REPORT,
    "report_schema_version": 4,
    "variants": [
        {
            **_SAMPLE_REPORT["variants"][0],
            "metrics": {
                **_SAMPLE_REPORT["variants"][0]["metrics"],
                "profile_breakdown": {
                    "aligned": {
                        **_DIAGNOSTIC_BUCKET,
                        "exit_reason_mix": {"signal:rsi_exit": 1},
                    },
                    "countertrend": {
                        "trades": 0,
                        "pnl": 0.0,
                        "gross_pnl": 0.0,
                        "fees_paid": 0.0,
                        "profit_factor": None,
                        "win_rate": None,
                        "avg_return_pct": None,
                        "avg_hold_bars": None,
                        "exit_reason_mix": {},
                    },
                    "neutral": {
                        "trades": 0,
                        "pnl": 0.0,
                        "gross_pnl": 0.0,
                        "fees_paid": 0.0,
                        "profit_factor": None,
                        "win_rate": None,
                        "avg_return_pct": None,
                        "avg_hold_bars": None,
                        "exit_reason_mix": {},
                    },
                },
                "exit_reason_breakdown": {
                    "signal:rsi_exit": _DIAGNOSTIC_BUCKET,
                },
                "fee_diagnostics": {
                    "total_fees_paid": 1.0,
                    "gross_pnl": 10.0,
                    "net_pnl": 9.0,
                    "fees_rate": 0.0006,
                    "fees_as_pct_of_gross_profit": 0.1,
                },
            },
            "trade_records": [
                {
                    **_SAMPLE_REPORT["variants"][0]["trade_records"][0],
                    "entry_profile": "aligned",
                    "entry_context_state": "up",
                    "active_exit_profile": "aligned",
                    "exit_group": "profile",
                    "exit_profile": "aligned",
                    "exit_component_id": "rsi_signal_exit",
                    "exit_instance_id": "rsi_exit",
                    "exit_kind": "signal",
                    "gross_pnl": 10.0,
                    "fees_paid": 1.0,
                    "gross_return_pct": 0.1,
                    "hold_bars": 3,
                    "hold_minutes": 15,
                }
            ],
        }
    ],
}


def _write_artifacts(
    results_dir: Path,
    *,
    schema_version: int = 3,
    payload: dict | None = None,
) -> str:
    if payload is None:
        payload = {**_SAMPLE_REPORT, "report_schema_version": schema_version}
    else:
        payload = {**payload, "report_schema_version": schema_version}
    run_id = str(payload["run_id"])
    runs = results_dir / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2)
    (runs / f"{run_id}.json").write_text(text, encoding="utf-8")
    (results_dir / "latest.json").write_text(text, encoding="utf-8")
    return run_id


def test_list_and_load_run(tmp_path: Path) -> None:
    run_id = _write_artifacts(tmp_path)
    summaries = list_run_summaries(results_dir=tmp_path)
    assert len(summaries) == 1
    assert summaries[0].run_id == run_id

    report = load_run_report(run_id=run_id, results_dir=tmp_path)
    assert report.report_schema_version == 3
    assert report.variants[0].trade_overlays[0].exit_reason == "stop_loss:sl1"


def test_load_schema_v4_report(tmp_path: Path) -> None:
    run_id = _write_artifacts(tmp_path, payload=_SAMPLE_REPORT_V4, schema_version=4)
    report = parse_run_report(json.loads((tmp_path / "runs" / f"{run_id}.json").read_text(encoding="utf-8")))
    assert report.report_schema_version == 4

    variant = report.variants[0]
    assert variant.metrics.profile_breakdown is not None
    aligned = variant.metrics.profile_breakdown["aligned"]
    assert aligned.gross_pnl == 10.0
    assert aligned.fees_paid == 1.0
    assert aligned.avg_return_pct == 0.09
    assert aligned.exit_reason_mix == {"signal:rsi_exit": 1}

    assert variant.metrics.exit_reason_breakdown is not None
    reason_bucket = variant.metrics.exit_reason_breakdown["signal:rsi_exit"]
    assert reason_bucket.avg_hold_bars == 3.0
    assert not hasattr(reason_bucket, "exit_reason_mix")

    fee = variant.metrics.fee_diagnostics
    assert fee is not None
    assert fee.fees_rate == 0.0006
    assert fee.net_pnl == 9.0

    trade = variant.trade_records[0]
    assert trade.entry_profile == "aligned"
    assert trade.active_exit_profile == "aligned"
    assert trade.exit_profile == "aligned"
    assert trade.gross_pnl == 10.0
    assert trade.hold_bars == 3

    report_from_disk = load_run_report(run_id=run_id, results_dir=tmp_path)
    assert report_from_disk.model_dump() == report.model_dump()


def test_load_schema_v3_report_still_valid(tmp_path: Path) -> None:
    run_id = _write_artifacts(tmp_path, schema_version=3)
    report = load_run_report(run_id=run_id, results_dir=tmp_path)
    assert report.report_schema_version == 3
    assert report.variants[0].metrics.profile_breakdown is None
    assert report.variants[0].trade_records[0].entry_profile is None


def test_unsupported_schema_version(tmp_path: Path) -> None:
    _write_artifacts(tmp_path, schema_version=99)
    with pytest.raises(UnsupportedSchemaVersionError):
        list_run_summaries(results_dir=tmp_path)


def test_http_runs_endpoints(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import research_api.services.results_reader as reader

    monkeypatch.setattr(reader, "default_results_dir", lambda: tmp_path)
    run_id = _write_artifacts(tmp_path)

    client = TestClient(app)
    assert client.get("/health").json() == {"status": "ok"}

    listed = client.get("/api/research/runs")
    assert listed.status_code == 200
    assert listed.json()[0]["run_id"] == run_id

    latest = client.get("/api/research/runs/latest")
    assert latest.status_code == 200
    assert latest.json()["run_id"] == run_id

    one = client.get(f"/api/research/runs/{run_id}")
    assert one.status_code == 200
    assert one.json()["variants"][0]["trade_records"][0]["exit_reason"] == "stop_loss:sl1"

    missing = client.get("/api/research/runs/does-not-exist")
    assert missing.status_code == 404


def test_validate_run_id_rejects_unsafe() -> None:
    with pytest.raises(InvalidRunIdError):
        validate_run_id("../latest")
    with pytest.raises(InvalidRunIdError):
        validate_run_id("foo/bar")
    with pytest.raises(InvalidRunIdError):
        validate_run_id("foo\\bar")


def test_http_invalid_run_id_returns_400(monkeypatch: pytest.MonkeyPatch) -> None:
    import research_api.services.results_reader as reader

    monkeypatch.setattr(reader, "default_results_dir", lambda: Path("/unused"))

    client = TestClient(app)
    # Single path segment after decode (encoded ``/`` is rejected by the ASGI stack with 404).
    for bad_id in ("%2E%2E", "foo%5Cbar", "bad%20id", "foo%40bar"):
        resp = client.get(f"/api/research/runs/{bad_id}")
        assert resp.status_code == 400, bad_id
        assert "Invalid run_id" in resp.json()["detail"]


def test_http_missing_valid_run_id_returns_404(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import research_api.services.results_reader as reader

    monkeypatch.setattr(reader, "default_results_dir", lambda: tmp_path)

    client = TestClient(app)
    valid_missing = "2026-05-01T120000Z_ema_pullback_BTCUSDT_5m"
    resp = client.get(f"/api/research/runs/{valid_missing}")
    assert resp.status_code == 404


def test_http_unsupported_schema(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import research_api.services.results_reader as reader

    monkeypatch.setattr(reader, "default_results_dir", lambda: tmp_path)
    _write_artifacts(tmp_path, schema_version=99)

    client = TestClient(app)
    resp = client.get("/api/research/runs")
    assert resp.status_code == 422
    assert "Unsupported report_schema_version" in resp.json()["detail"]
