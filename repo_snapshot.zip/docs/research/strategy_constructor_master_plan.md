# Strategy Constructor — Master Plan

> Стратегический план post-MVP research-слоя.  
> Документ фиксирует направление, но не является ТЗ текущей фазы.

---

## 1. Цель

После Phase 4 MVP smoke backtest построить отдельный research-слой для разработки, сравнения и проверки торговых стратегий через `vectorbt`.

`data_engine/` остаётся только слоем данных:

```text
Bybit → SQLite → DIM → clean candles
```

Strategy Constructor живёт отдельно в `research/`:

```text
clean candles → strategy components → vectorbt → metrics/report
```

---

## 2. Что НЕ входит в Data Engine

Торговая логика не должна попадать в core:

- стратегии;
- сигналы входа/выхода;
- risk/sizing;
- optimizer;
- strategy registry;
- backtest reports;
- strategy configs.

Всё это находится в `research/`, не в `data_engine/`.

---

## 3. Базовые понятия

### Strategy Family

Общее семейство стратегии.

Пример:

```text
ema_pullback
```

Family описывает общий подход, но не фиксирует конкретные компоненты и параметры.

---

### Strategy Variant

Конкретная логическая сборка внутри family.

Пример:

```text
direction: EMA trend
blockers: ATR range + distance from EMA
setup: pullback
trigger: breakout
exit: ATR stop/take
risk: fixed fraction
```

Variant может отличаться не только параметрами, но и самими компонентами.

---

### Strategy Instance

Конкретный запуск variant с параметрами:

```text
family + variant + config + symbol + timeframe + date range
```

---

### Experiment

Запуск одного или нескольких strategy instances на выбранных данных.

---

### Result

Результат backtest:

```text
config_id
family
variant
symbol
timeframe
trades
return
drawdown
sharpe
profit_factor
debug counters
```

---

## 4. Strategy Pipeline

Стратегия должна строиться как pipeline:

```text
Data
↓
Features
↓
Direction
↓
Blockers
↓
Setup
↓
Trigger / ТВХ
↓
Exit
↓
Risk / Sizing
↓
Vectorbt Portfolio
↓
Report
```

Компоненты должны быть заменяемыми через config.

---

## 5. Rollout

### Step 0 — Phase 4 MVP Smoke

До конструктора делаем только:

```text
research/ema_smoke.py
```

Цель:

```text
clean candles → simple EMA crossover → vectorbt stats
```

Без framework, registry и optimizer.

---

### Step 1 — Strategy Family Skeleton

Создать первую family:

```text
research/strategies/ema_pullback/
```

Минимально:

```text
features.py
signals.py
configs.py
run.py
```

Цель: одна стратегия, один config, один backtest.

---

### Step 2 — Pipeline Decomposition

Разделить стратегию на блоки:

```text
features
direction
blockers
setup
trigger
exit
risk
```

Цель: перестать писать стратегию одной большой формулой.

---

### Step 3 — Strategy Config / Instance

Ввести config и `config_id`.

Config должен описывать:

```text
family
variant
symbol
timeframe
features
direction
blockers
setup
trigger
exit
risk
fees/slippage
date range
```

Цель: один код стратегии, много экземпляров.

---

### Step 4 — Manual Variants

Создать несколько ручных вариантов:

```text
base
conservative
aggressive
```

Сравнить результаты в единой таблице.

---

### Step 5 — FeaturesDev Layer

Перед внедрением component registry вводим отдельный слой подготовки признаков.

FeaturesDev — это research-only слой внутри strategy family. Для ema_pullback он живёт в:

```text
research/strategies/ema_pullback/features.py
```

Задача слоя — заранее подготовить вычислимые признаки и смысловые привязки для компонентов. Компоненты не должны сами считать EMA, RSI, ATR, trend/context и другие индикаторы внутри себя.

Важный принцип:

- `features.py` считает признаки рынка.
- `components` используют подготовленные признаки и смысловые relations/bindings.
- `signals.py` соединяет outputs компонентов.
- `run.py` запускает experiment.

fast / slow — это роли внутри relation, а не свойства самой EMA. Одна и та же EMA может быть slow в одной relation и fast в другой.

intraday / swing / daily — это смысловые роли для RSI или других признаков, а не жёстко зашитые имена индикаторов.

Подробные правила FeatureSeries, FeatureBinding и FeatureRelation фиксируются в отдельном плане Stage 5.

---

### Step 6 — Component Registry

Добавить registry компонентов:

```text
DIRECTION_REGISTRY
BLOCKER_REGISTRY
SETUP_REGISTRY
TRIGGER_REGISTRY
EXIT_REGISTRY
RISK_REGISTRY
```

Цель: менять не только параметры, но и саму логику блоков через config.

---

### Step 7 — First Real Component Variant

Stage 7 создаёт первую полную component-based сборку стратегии внутри `ema_pullback`.

Цель не в том, чтобы сделать много компонентов. Цель — доказать, что цепочка registry/config/instance/composer может запустить новую торговую логику, собранную из component ids.

В Stage 7 вводятся только два новых реальных компонента:

- реальный `setup` component, например `pullback_to_fast_ema`;
- реальный `trigger` component, например `reclaim_fast_ema`.

Все обязательные роли по-прежнему должны присутствовать в сборке StrategyConfig/StrategyInstance:

```text
direction_component = существующий/дефолтный ema_trend
blockers_component = существующий/дефолтный no_blockers
setup_component = NEW pullback_to_fast_ema
trigger_component = NEW reclaim_fast_ema
exits_component = существующий/дефолтный ema_cross_down
risk_component = существующий/дефолтный no_risk_filter
```

Практический scope Stage 7:

- зарегистрировать новые `setup`/`trigger` в family-local registry `ema_pullback`;
- собрать один manual variant на новых component ids;
- сравнить этот variant с существующими baseline/manual variants;
- при необходимости сохранить старые variants как контрольную группу.

Критерий успеха:

```text
новая component-based сборка работает в runner и сравнивается с baseline.
```

Важно:

- прибыльность стратегии не является критерием успеха Stage 7;
- Stage 7 не должен делать grid/optimizer/framework.

Ограничения Stage 7:

- не делать component grid;
- не делать optimizer;
- не делать parameter sweep;
- не делать YAML/JSON strategy config;
- не делать frontend/visual constructor;
- не менять `data_engine/`;
- не добавлять live trading/execution/order routing;
- не строить global framework.

---

### Step 8 — Feature-based Trade Management / SL-TP (historical, superseded)

Историческая формулировка этапа: после первой реальной component-based стратегии вводится отдельный слой управления открытой сделкой.
Актуальная архитектура для `ema_pullback` зафиксирована позже (Step 12): выходы и SL/TP описываются через `components.exits`, а корневой `TradeManagementSpec` зарезервирован.

Trade Management не является FeaturesDev и не является entry-логикой.

FeaturesDev готовит признаки, anchors и relations:

```text
ATR
EMA anchors
higher-timeframe EMA levels
volatility context
trend relations
```

Исторически Trade Management описывался как слой, использующий prepared feature bindings/relations для правил фиксации прибыли и убытка:

```text
stop_loss
take_profit
time_stop
later: trailing_stop / partial exits
```

Историческая заметка: `trade_management_profile` рассматривался как часть `StrategyConfig` и `config_id`.
Для текущей модели `ema_pullback` это заменено спецификацией выходов в `components.exits` (см. Step 12).

Component Grid начинается только после базового Trade Management, потому что массово тестировать входы без стабильной архитектуры stop/take даёт искажённые выводы.

---

### Step 9 — Research Results Artifact / Experiment Report (updated by later spec steps)

После первой реальной component-based стратегии нужно перестать опираться только на stdout-таблицу runner.

Research runner формирует структурированный результат запуска:

```text
research/results/*.json
```

Минимальный смысл: `run.py` → structured experiment result artifact.

Артефакт (минимум): `run_id`, `timestamp`, `family`, `symbol`, `timeframe`, `candles`, `variants`, `config_id`, `feature_profile`, component ids, `trades`, `sharpe`, `profit_factor`, `max_drawdown`, `total_return` (позже).

Примечание: поле `trade_management_profile` относится к исторической формулировке ранних шагов; в актуальной модели источником семантики выходов является `components.exits` (см. Step 12).

Цель: результаты backtest воспроизводимы, сравнимы и пригодны для будущего dashboard/grid.

Сюда не входят: база данных, frontend, optimizer, component grid. Это простой structured artifact для research runs. Stdout-таблица может остаться, но JSON/report artifact — стабильный источник для следующих этапов.

---

### Step 10 — EMA Pullback StrategySpec / Anchor Stack Refactor

После появления JSON-отчётов перед frontend/grid стабилизируем внутреннюю модель `ema_pullback`.

Цель этапа — уйти от ручной модели `FeatureRelation` как основного способа задания стратегии и перейти к явному `StrategySpec` для конкретного экземпляра `ema_pullback`.

`ema_pullback` остаётся названием strategy family.

Новая модель должна описывать стратегию через параметризуемую anchor-конструкцию:

```text
fast EMA
anchor EMA
slow EMA
```

Базовая идея стратегии:

торговать pullback к anchor EMA,
если fast EMA > anchor EMA > slow EMA

`FeatureRelation` может остаться временным legacy/compiled helper, но не должен быть главным местом, где задаётся стратегия.

После этого этапа frontend и будущий grid должны опираться на `StrategySpec`, а не на ручные `intraday_trend` / `swing_trend` relations.

---

### Step 11 — Bidirectional Side Semantics

На шаге 11 вводится семантика учёта направления сделки (long/short) и подготовка исполнения компонентов к этому контексту; подробные контракты вызова компонентов зафиксированы в отдельном плане реализации шага 11.

---

### Step 12 — Side-aware компоненты и единая архитектура выходов

**Компонентный слой:** blocker / risk / exit / trigger остаются **side-aware** — одна и та же идея зеркально для long и short.

**Spec:** вместо раздельных «signal exits» на стеке и rich **trade management** с distance-rules на корне стратегии — **один список `components.exits`** (`ExitRuleSpec`: signal / stop_loss / take_profit и при необходимости ATR-distance). **`TradeManagementSpec`** на `EmaPullbackStrategySpec` — зарезервированный профиль без списка правил; SL/TP и сигнальные выходы задаются только через **`exits`**.

**Execution:** применение выходов сосредоточено в отдельном слое исполнения (orchestration + exits), а не размазано по runner и только входным компонентам.

**Construction (тот же шаг по охвату roadmap):** typed **`component_builders.py`** и миграция **`spec_instances`** на единый pure-builder путь сборки spec-объектов — мост к Step 14 (внешний instance dict без второго способа ручной сборки dataclass-ов).

---

### Step 13 — Multi-instance компонентов в одном strategy instance

После стабилизации side-aware компонентов и unified `exits` нужно разрешить повторное использование одного и того же component id в рамках одной роли с разными параметрами.

**Цель:**

- поддержать несколько экземпляров одного типа компонента (например, несколько `blockers`/`exits`) в одном `StrategySpec`;
- ввести стабильные `instance_id`/алиасы для различения экземпляров и детерминированной диагностики;
- зафиксировать единый целевой multi-instance формат как основной контракт шага.

**High-level scope:**

- расширить contracts builder/execution так, чтобы компонент мог присутствовать в конфиге как список instances;
- определить порядок выполнения и агрегацию результатов для одинаковых component ids с разными params;
- включить `instance_id` в debug/reporting слой (`research/results`) для воспроизводимого анализа.

Подробный контракт и подшаги — в отдельном плане `docs/research/13_multi_instance_components_plan.md`.

---

### Step 14 — External Config Loader (Experiment Layer + Family Parser)

После стабилизации typed builders и multi-instance компонентов вводится двухуровневый внешний слой конфигурации: generic experiment layer и family-local parser.

Шаг переводит систему из режима «инстанс собирается вручную в коде» в режим «external config file проходит generic envelope-валидацию, dispatch по family, затем family parser собирает typed spec».

**Step 14A (family-local, `ema_pullback`):**

- добавить `instance_loader.py` в `research/strategies/ema_pullback/`;
- контракт уровня family: один instance `dict` -> `EmaPullbackStrategySpec`;
- использовать только builder path (`component_builders/spec_instances`);
- валидировать family-specific поля (trigger/blockers/exits/anchor_stack и т.д.) с fail-fast.

**Step 14B (generic experiment layer, minimal MVP):**

- добавить минимальный `research/experiments/config_loader.py`;
- читать один внешний config file (single instance object или bundle/list instances);
- валидировать общий envelope (`schema_version`, `experiment_id`/`run_name`, `family`, `instances`);
- делать dispatch по `family` в family-local parser;
- возвращать список typed specs и metadata для batch report.

**Boundary (жёсткое разделение ответственности):**

- `research/strategies/ema_pullback/` знает только, как из одного dict собрать свою стратегию;
- file ingestion, batch orchestration, experiment lifecycle и cross-family сравнение живут выше — в `research/experiments/`;
- strategy-family слой не должен содержать generic file/batch/grid logic.

**MVP ограничения шага:**

- только single config file ingestion;
- no partial execution: fail-fast на весь файл/bundle;
- без grid/optimizer/parameter sweep;
- без config directory discovery (это follow-up).

Подробный контракт и подшаги — в отдельном плане `docs/research/14_external_config_loader_plan.md`.

---

### Step 15 — OHLC-aware vectorbt execution (family runner)

**Цель:** перевести vectorbt execution с **close-only** на **OHLC-aware**, без изменения семантики стратегии и без изменения внешнего **config-контракта** (`StrategySpec` / YAML envelope остаются как есть).

**Сделать:** в execution path family (например `ema_pullback`, `run_strategy_spec`) передавать в `Portfolio.from_signals` те же `open`, `high`, `low`, что уже доступны в обогащённом OHLCV после feature layer, параллельно с `close`.

**Замечание:** equity и список сделок могут **слегка** разойтись с прошлым close-only (стопы в vectorbt учитывают high/low); это ожидаемая плата за согласованность с реальными тенями свечей. Зафиксировать в family README / заметке к релизу.

Подробный контракт и подшаги — в отдельном плане `docs/research/15_ohlc_aware_vectorbt_plan.md`.

---

### Step 16 — exit_reason attribution (research JSON)

После Step 9 (artifact), Step 12–13 (unified `exits`, multi-instance) и **Step 15 (OHLC-aware `from_signals`)** в `trade_records` удобно иметь **персделочную** причину закрытия, а не только агрегированные counters и плейсхолдер `unknown`.

**Цель кратко:** заполнять в JSON осмысленный `exit_reason` (например SL / TP / signal с привязкой к `instance_id` правила), согласованно с порядком исполнения vectorbt (стоп vs пользовательский exit signal), без изменений в `data_engine/`.

Подробный контракт, формат полей, приоритеты при коллизиях и ограничения (trailing / custom adjust и т.д.) — в отдельном плане `docs/research/16_exit_reason_attribution_plan.md`.

---

### Step 17 — Component Grid

Component Grid запускается только после того, как появятся структурированные результаты research-прогонов: без стабильного хранения результатов массовый прогон вариантов превращается в шумный и плохо сопоставимый `stdout`.

После появления нескольких реальных компонентов (включая side-aware blocker / risk / exit / trigger из Step 12) добавить ограниченный перебор комбинаций.

Grid должен:

- работать только по уже существующим component ids;
- не появляться раньше, чем есть хотя бы несколько осмысленных `setup/trigger/blocker/exit` components.

Ограничения:

- всё ещё без optimizer;
- всё ещё без global framework;
- без auto-discovery/plugin system;
- без изменений в `data_engine/`.

---

### Step 18 — Debug Reports / Diagnostics

Расширение отчётности поверх базового structured artifact: debug counters, сделочная диагностика, причины входов/выходов (в т.ч. поверх машиночитаемого `exit_reason` из Step 16).

Примеры счётчиков:

```text
direction_ok_count
setup_count
blocked_count
entry_count
trade_count
```

---

### Step 19 — Validation

Добавить защиту от самообмана:

- train/test split;
- parameter stability;
- fees/slippage sensitivity;
- minimum trades filter;
- out-of-sample report.

---

## 6. Guardrails

До Phase 4 не делать:

- strategy framework;
- component registry;
- optimizer;
- walk-forward framework;
- result database;
- live trading;
- перенос стратегий в `data_engine/`.

После Phase 4 внедрять только пошагово.

Roadmap note:

FeaturesDev keeps indicator calculation out of components. Exit rules (signal and ATR-based SL/TP) live in `StrategySpec` under `components.exits` and are evaluated via a dedicated execution exits path, so runner and entry-side code stay orchestration-focused. Research Results Artifact (Step 9) supports structured run output. Step 15 moves vectorbt execution from close-only to OHLC-aware `from_signals` without changing strategy or external config contract. Step 16 adds per-trade `exit_reason` in JSON for analyzable experiments ahead of Component Grid (Step 17). EMA Pullback StrategySpec / anchor stack refactor stabilises the internal instance model after artifacts. Bidirectional Side Semantics (`TradeSideSpec`, long/short vectorbt wiring) follows StrategySpec so `ema_pullback` is not long-only. Step 12 completes side-aware blocker / risk / exit / trigger wiring and this **unified exits + reserved root trade_management** architecture, plus typed `component_builders` as the single construction layer ahead of external config. Step 13 introduces multi-instance component support (same component id reused with different params and explicit instance ids). Step 14 then splits responsibilities: experiment layer reads/validates one external config file and dispatches by family, while `ema_pullback` only parses one instance dict into `EmaPullbackStrategySpec`. Directory discovery, grid/optimization, and richer lifecycle orchestration remain follow-up. Component Grid (Step 17) remains postponed until FeaturesDev, components, result artifacts, StrategySpec, side-aware specs, live components, builders, multi-instance support, this boundary-safe external config flow, OHLC-aware execution, and usable per-trade exit attribution are stable.

---

## 7. Основной принцип

Не строить полноценный Strategy Constructor до первого живого backtest.

Порядок:

```text
0. dumb EMA smoke
1. strategy family skeleton
2. pipeline decomposition
3. strategy config / instance
4. manual variants
5. featuresdev layer
6. component registry
7. first real component variant
8. trade management / SL-TP
9. research results artifact
10. ema_pullback StrategySpec / anchor stack refactor
11. bidirectional side semantics (TradeSideSpec, long / short)
12. side-aware blocker / risk / exit / trigger + unified `exits` spec, execution exits layer, `component_builders`
13. multi-instance same component support (different params, explicit `instance_id`)
14. external config loader (experiment layer + family parser)
15. OHLC-aware vectorbt execution (`from_signals` with open/high/low)
16. exit_reason attribution (research JSON `trade_records`)
17. component grid
18. debug report / diagnostics
19. validation
```

Итоговая цель:

```text
Data Engine даёт чистые данные.
Research layer собирает и проверяет стратегии.
Core data engine не загрязняется торговой логикой.
```

---

## Future direction: Visual Strategy Constructor

В будущем Strategy Constructor может получить визуальный слой конфигурации стратегий.
Это отложенное направление (not current scope), не часть текущего Stage 4 и не изменение текущей дорожной карты.

Идея high-level:

- пользователь собирает стратегию из blocks/components на визуальном canvas;
- блоки могут соответствовать слоям `direction`, `blockers`, `setup`, `triggers`, `exits`, `risk`;
- связи между блоками могут выражать pipeline и логические зависимости;
- условия могут поддерживать простые композиции `AND` / `OR` / `NOT`;
- параметры компонентов редактируются через UI;
- результат визуальной сборки сохраняется не как frontend-specific state, а как строгий `StrategySpec` / Strategy AST / JSON-like representation.

Архитектурный принцип:

- UI graph is not the strategy itself.
- UI graph should compile into a validated `StrategySpec`.
- `StrategySpec` should be validated and then converted into `StrategyInstance`.
- Research/backtest execution remains on the research side.
- Frontend must not dictate the internal architecture of `data_engine/` or research execution.
- `data_engine/` must remain unaware of strategies and visual configuration.

Потенциальные направления (без финального выбора):

- node-based editor libraries such as React Flow / xyflow may be considered later;
- Blockly / JsonLogic-like approaches may be considered later for condition builders;
- heavier workflow engines should not be adopted without a separate architecture decision.

Phased note:

- first build strict Python/JSON strategy model;
- then validate component registry and component composition;
- only after that consider visual UI;
- avoid building a large visual programming framework prematurely.
